//
// Created by 12147 on 2024/10/2.
//
#include "main.h"
#include "stm32f4xx_hal_def.h"
#include "stm32f4xx_hal.h"
#include "tim.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == htim1.Instance)
    {
        HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
    }
}
